"""My first program for COMP110)."""
__author__ = "730514525"

print("Hello, world.")
print("Hello, coffee world.")