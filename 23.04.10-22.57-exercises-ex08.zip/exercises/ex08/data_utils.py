"""EX08."""
__author__ : "730514525"


from csv import DictReader


def read_csv_rows(filename: str) -> list[dict[str,str]]:
    """Read csv file and return as a list of dicts eiht header keys."""
    result: list[dict[str,str]] = []
    file_handle = open(filename, "r", encoding = "utf8")
    csv_reader = DictReader(file_handle)
    for row in csv_reader:
        result.append(row)
    file_handle.close()
    return result


def column_values(table: list[dict[str,str]], header: str) -> list[str]:
    """Returns values in a table column under a certain header."""
    result: list[str] = []
    for row in table:
        result.append(row[header])
    return result 


def columnar(table: list[dict[str,str]]) -> dict[str,list[str]]:
    """Reformats data so that it's a dictionary with column headers as keys."""
    result: dict[str,list[str]] = {}
    first_row: dict[str,str] = table[0]
    for key in first_row:
        result[key] = column_values(table,key)
    return result


def head(col_based_table: dict[str, list[str]], n: int) -> dict[str, list[str]]:
    """Produces a new column based table with only the first N rows of data for each column."""
    new_dict: dict[str, list[str]] = {}
    idx: int = 0
    if len(col_based_table) <= n:
        return col_based_table
    for key in col_based_table:
        n_list: list[str] = []
        while idx < n:
            n_list.append(col_based_table[key][idx])
            idx += 1
        new_dict[key] = n_list
        n_list = []
        idx = 0
    return new_dict


def select(col_based_table: dict[str, list[str]], col_names: list[str]) -> dict[str, list[str]]:
    """Produces a new column-based table with only a specific subset of the original columns."""
    new_dict: dict[str, list[str]] = {}
    for item in col_names:
        for name in col_names:
            if name == item:
                new_dict[item] = col_based_table[item]
    return new_dict


def concat(col_based_table1: dict[str, list[str]], col_based_table2: dict[str, list[str]]) -> dict[str, list[str]]:
    """Produce a new col-based table with two col-based tables combined."""
    new_dict: dict[str, list[str]] = {}
    for column in col_based_table1:
        new_dict[column] = col_based_table1[column]
    for column in col_based_table2:
        if column in new_dict.keys():
            new_dict[column] += col_based_table2[column]
        else:
            new_dict[column] = col_based_table2[column]
    return new_dict


def count(strlist: list[str]) -> dict[str, int]:
    """Given a list of str produces a dict [str,int] where each key is a unique value in the fiven list and each value associated is the ocunt of hte number of times that value appeared in the input list."""
    new_dict: dict[str, int] = {}
    for item in strlist:
        if item in new_dict:
            new_dict[item] += 1
        else:
            new_dict[item] = 1
    return new_dict