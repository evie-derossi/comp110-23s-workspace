"""Utility class for numerical operations."""

from __future__ import annotations

from typing import Union

__author__ = "730514525"


class Simpy:
    """Creates simpy obj."""

    values: list[float]

    def __init__(self, fltlist: list[float]) -> None: 
        """Initialize the values attribute of the newly constructed simpy object to the arg passedd in."""
        self.values: list[float] = fltlist
    
    def __str__(self) -> str:
        """Convert to str."""
        return f"Simpy({self.values})"
    
    def fill(self, valfiller: float, amnttofill: int) -> None:
        """Fill a simpy values with a specific number of repeating values."""
        result: list[float] = []
        while len(result) < amnttofill:
            result.append(valfiller)
        self.values = result

    def arange(self, start: float, stop: float, step: float = 1.0) -> None:
        """Fill in values with range of values."""
        assert step != 0
        result: list[float] = []
        if step < 0.0:
            while start > stop:
                result.append(start)
                start += step
        else:
            while start < stop:
                result.append(start)
                start += step
        self.values = result

    def sum(self) -> float:
        """Compute and return sum of all items in values."""
        result: float = sum(self.values)
        return result
    
    def __add__(self, rhs: Union[Simpy, float]) -> Simpy:
        """Make it so the rhs operand of + expression can be either Simpy or float."""
        result: list[float] = []
        if type(rhs) == float:
            a: int = 0
            while a < len(self.values):
                result.append(self.values[a] + rhs)
                a += 1
        else:
            assert len(self.values) == len(rhs.values)
            b: int = 0
            while b < len(self.values):
                result.append(self.values[b] + rhs.values[b])
                b += b
        new_simpy_object: Simpy = Simpy(result)
        return new_simpy_object
    
    def __pow__(self, rhs: Union[Simpy, float]) -> Simpy:
        """Exponentiation."""
        result: list[float] = []
        if type(rhs) == float:
            a: int = 0
            while a < len(self.values):
                result.append(self.values[a] ** rhs)
                a += 1
        else:
            assert len(self.values) == len(rhs.values)
            b: int = 0
            while b < len(self.values):
                result.append(self.values[b] ** rhs.values[b])
                b += 1
        new_simpy_object: Simpy = Simpy(result)
        return new_simpy_object
    
    def __eq__(self, rhs: Union[Simpy, float]) -> list[bool]:
        """Check for equal."""
        result: list[bool] = []
        if type(rhs) == float:
            a: int = 0
            while a < len(self.values):
                result.append(self.values[a] == rhs)
                a += 1
            else:
                assert len(self.values) == len(rhs.values)
                b: int = 0
                while b < len(self.values):
                    result.append(self.value[b] == rhs.values[b])
                    b += 1
            return result
    
    def __gt__(self, rhs: Union[Simpy, float]) -> list[bool]:
        """Test for greater than."""
        result: list[bool] = []
        if type(rhs) == float:
            a: int = 0
            while a < len(self.values):
                result.append(self.values[a] == rhs)
                a += 1
            else:
                assert len(self.values) == len(rhs.values)
                b: int = 0
                while b < len(self.values):
                    result.append(self.value[b] == rhs.values[b])
                    b += 1
            return result
    
    def __getitem__(self, rhs: Union[int, list[bool]]) -> Union[float, Simpy]:
        """Add susbcription operator for Simpy object."""
        if type(rhs == int):
            assert rhs < len(self.values)
            fltresult: float = 0.0
            fltresult = self.values[rhs]
            return fltresult
        else:
            a: int = 0
            result: list[float] = []
            while a < len(self.values):
                if rhs[a]:
                    result.append(self.values[a])
                a += 1
            new_simpy_object: Simpy = Simpy(result)
            return new_simpy_object