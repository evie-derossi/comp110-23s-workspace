"""EX05 list utility functions."""
__author__ = "730514525"


def only_evens(int_list: list[int]) -> list[int]:
    """Given a list of ints, returns a new list containing only even elements."""
    evens: list[int] = list()
    for number in int_list:
        if number % 2 == 0:
            evens.append(number)
    return evens


def concat(int_list1: list[int], int_list2: list[int]) -> list[int]:
    """Given two lists, returns a new list of list1 followed by list2."""
    new_list: list[int] = list()
    for number in int_list1:
        new_list.append(number)
    for number in int_list2:
        new_list.append(number)
    return new_list


def sub(int_list: list[int], start_idx: int, end_idx: int) -> list[int]:
    """Given a list of ints, start idx, and end idx returns list that is subset of given list."""
    new_list: list[int] = list()
    if start_idx < 0:
        start_idx = 0
    if end_idx > len(int_list):
        end_idx = len(int_list)
    if len(int_list) == 0:
        return new_list
    while start_idx < end_idx:
        new_list.append(int_list[start_idx])
        start_idx += 1
    return new_list