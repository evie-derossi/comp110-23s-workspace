"""Unit tests for EX05."""
__author__ = "730514525"

from ex05.utils import only_evens, sub, concat


def test_only_evens_edge() -> None:
    """Edge test for only_evens."""
    int_list: list[int] = []
    only_evens(int_list)


def test_only_evens_use1() -> None:
    """Use test for only_evens."""
    int_list: list[int] = [1, 2, 3, 4]
    only_evens(int_list)


def test_only_evens_use2() -> None:
    """Use test for only_evens."""
    int_list: list[int] = [1, 2, 4, 9, 12]
    only_evens(int_list)


def test_concat_edge() -> None:
    """Edge test for concat."""
    int_list1: list[int] = []
    int_list2: list[int] = []
    concat(int_list1, int_list2)


def test_concat_use1() -> None:
    """Use test for concat."""
    int_list1: list[int] = [1, 2, 3]
    int_list2: list[int] = [4, 5, 6]
    concat(int_list1, int_list2)


def test_concat_use2() -> None:
    """Use test for concat."""
    int_list1: list[int] = [7, 8, 9]
    int_list2: list[int] = [10, 11, 12]
    concat(int_list1, int_list2)


def test_sub_edge() -> None:
    """Edge test for sub."""
    int_list: list[int] = [1, 2, 3, 4, 5]
    start_idx: int = 4
    end_idx: int = 2
    sub(int_list, start_idx, end_idx)


def test_sub_use1() -> None:
    """Use test for sub."""
    int_list: list[int] = [1, 2, 3, 4, 5]
    start_idx: int = 1
    end_idx: int = 3
    sub(int_list, start_idx, end_idx)


def test_sub_use2() -> None:
    """Use test for concat."""
    int_list: list[int] = [1, 2, 3, 4, 5, 7, 8, 9, 10]
    start_idx: int = 3
    end_idx: int = 7
    sub(int_list, start_idx, end_idx)