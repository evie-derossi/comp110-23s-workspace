"""List Utility Functions."""
__author__ = "730514525"


def all(intlist: list[int], givenint: int) -> bool:
    """Given a list of ints and an int returns True if all numbers match givenint."""
    idx: int = 0
    if len(intlist) == 0:
        return False
    while idx < len(intlist):
        if intlist[idx] != givenint:
            return False
        idx += 1
    return True


def max(intlist: list[int]) -> int:
    """Given a list returns max number."""
    idx: int = 0
    largest: int = intlist[0]
    if len(intlist) == 0:
        raise ValueError("max() arg is an empty List")
    else:
        while idx < len(intlist):
            if largest < intlist[idx]:
                largest = intlist[idx]
            idx += 1
        return largest 


def is_equal(intlist1: list[int], intlist2: list[int]) -> bool:
    """Given two lists checks if they are deepy equal."""
    idx: int = 0
    if len(intlist1) != len(intlist2):
        return False
    while idx < len(intlist1):
        if intlist1[idx] == intlist2[idx]:
            idx += 1
        else:
            return False
    return True
