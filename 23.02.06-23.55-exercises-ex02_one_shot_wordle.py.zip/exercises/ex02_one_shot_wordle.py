"""EX02 One Shot Wordle."""
__author__ = "730514525"

SECRET: str = "python"
guess: str = input(f"What is your {len(SECRET)}-letter guess? ")
playing: bool = True
w_or_y: bool = False
idx: int = 0
idx2: int = 0
WHITE_BOX: str = "\U00002B1C"
GREEN_BOX: str = "\U0001F7E9"
YELLOW_BOX: str = "\U0001F7E8"
box_answer: str = ""

while playing:
    while len(guess) != len(SECRET):
        guess = input(f"That was not {len(SECRET)} letters! Try again: ")
    while idx < len(guess):
        if guess[idx] == SECRET[idx]:
            box_answer = box_answer + GREEN_BOX
        else:
            while idx2 < len(SECRET) and not w_or_y:
                if guess[idx] == SECRET[idx2]:
                    w_or_y = True
                idx2 = idx2 + 1
            if w_or_y:
                box_answer = box_answer + YELLOW_BOX
            else:
                box_answer = box_answer + WHITE_BOX
        idx = idx + 1 
        w_or_y = False
        idx2 = 0                
    if guess == SECRET:
        print(box_answer)
        print("Woo! You got it! ") 
    else: 
        print(box_answer)
        print("Not quite. Play again soon! ")
    playing = False
    