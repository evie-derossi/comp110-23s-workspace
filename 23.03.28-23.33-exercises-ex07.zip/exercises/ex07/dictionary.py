"""EX07 Dicitonary Functions."""
__author__ = "730514525"


def invert(input: dict[str, str]) -> dict[str, str]:
    """Given a dict of str,str, returns dict of str, str that inverts the keys and values."""
    new_dict: dict[str, str] = {}
    for key in input:
        new_value: str = key
        new_key: str = input[key]
        if new_key in new_dict:
            raise KeyError("Keys cannot be duplicates. ")
        else:
            new_dict[new_key] = new_value
    return new_dict


def favorite_color(input: dict[str, str]) -> str:
    """Given a dict of names and favorit colors returns the most frequent color."""
    count: dict[str, int] = {}
    for color in input.values():
        if color in count:
            count[color] += 1
        else:
            count[color] = 1
    favorite: str = ""
    most_frequent: int = 0
    for key in count.keys():
        if count[key] > most_frequent:
            favorite = key
            most_frequent = count[key]
    return favorite


def count(strlist: list[str]) -> dict[str, int]:
    """Given list of str produces dict where each key is a unique value in the given list and each value associated is the count of # of times value appeared."""
    new_dict: dict[str, int] = {}
    for item in strlist:
        if item in new_dict:
            new_dict[item] += 1
        else:
            new_dict[item] = 1
    return new_dict