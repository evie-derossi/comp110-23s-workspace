"""Tests for EX07."""
__author__ = "730514525"

from exercises.ex07.dictionary import invert, favorite_colors, count


def test_invert_edge() -> None:
    """Edge test for invert."""
    input: dict[str, str] = []
    invert(input)


def test_invert_use1() -> None:
    """Use test for invert."""
    input: dict[str, str] = {"hi": "hello", "your": "mom", "comp": "sucks"}
    invert(input)


def test_invert_use2() -> None:
    """Use test for invert."""
    input: dict[str, str] = {"candy": "crush", "poker": "face", "gold": "ring"}
    invert(input)


def test_favorite_color_edge() -> None:
    """Edge test for favorite_colors."""
    input: dict[str, str] = {"George": 2, "Georgina": 3}
    favorite_colors(input)


def test_favorite_color_use1() -> None:
    """Use test for favorite_colors."""
    input: dict[str, str] = {"Alan": "blue", "Grace": "red", "Gertrude": "green"}
    favorite_colors(input)


def test_favorite_color_use2() -> None:
    """Use test for favorite_colors."""
    input: dict[str, str] = {"Xan": "green", "Evie": "pink", "Juniper": "green"}
    favorite_colors(input)


def test_count_edge() -> None:
    """Edge test for count."""
    strlist: list[str] = [1, 2, "three"]
    count(strlist)


def test_count_use1() -> None:
    """Use test for count."""
    strlist: list[str] = ["one", "two", "three"]
    count(strlist)


def test_count_use2() -> None:
    """Use test for count."""
    strlist: list[str] = ["four", "five", "five", "six", "seven"]
    count(strlist)